import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-O5J3CNTX.js";
import "./chunk-6DU2HRTW.js";
export default require_cjs();
